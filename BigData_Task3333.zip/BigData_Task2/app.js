const express = require('express');
const mongoose = require('mongoose');
const methodOverride =require('method-override');

const app = express();
app.set('view engine' ,'ejs');
app.use(express.json());
app.use(express.urlencoded({extended: true}));
app.use(methodOverride('-_method'));

// الاتصال بـ MongoDB
mongoose.connect('mongodb://localhost:27017/bigdata')
  .then(() => console.log('MongoDB related succesfully'))
  .catch(err => console.log('خطأ في الاتصال:', err));
  //موديل المنتج
const productSchema = new mongoose.Schema({
  name: String,
  price: Number
});

const Product = mongoose.model('Product', productSchema);

// إضافة منتج (POST)
// الصفحة الرئيسية: عرض الكل + إضافة
app.get('/', async (req, res) => {
  const products = await Product.find();
  res.render('index', { products });
});

// إضافة منتج
app.post('/products', async (req, res) => {
  const product = new Product(req.body);
  await product.save();
  res.redirect('/');
});

// صفحة التعديل
app.get('/edit/:id', async (req, res) => {
  const product = await Product.findById(req.params.id);
  res.render('edit', { product });
});

// تعديل منتج
app.put('/products/:id', async (req, res) => {
  await Product.findByIdAndUpdate(req.params.id, req.body);
  res.redirect('/');
});

// حذف منتج
app.delete('/products/:id', async (req, res) => {
  await Product.findByIdAndDelete(req.params.id);
  res.redirect('/');
});
app.listen(3000, () =>{console.log('Server Running on http://localhost:3000');});